#include <pebble.h>

// ============================================================================
// METAL GEAR WATCHFACE
// Target: Emery (Pebble Time 2, 200x228, 64 colors)
// Falls back to other platforms via PBL_COLOR / dynamic bounds
// ============================================================================

// ============================================================================
// COLOR PALETTE
// ============================================================================

#ifdef PBL_COLOR
  // Shadow Moses palette
  #define COL_WALL_BACK     GColorDarkGray
  #define COL_WALL_PANEL    GColorLightGray
  #define COL_WALL_LINE     GColorBlack
  #define COL_FLOOR         GColorBlack
  #define COL_FLOOR_HI      GColorDarkGray
  #define COL_PIPE          GColorDarkGray
  #define COL_PIPE_HI       GColorLightGray
  #define COL_LAMP          GColorYellow
  #define COL_CAUTION_Y     GColorChromeYellow
  #define COL_CAUTION_K     GColorBlack
  #define COL_VENT          GColorDarkGray
  #define COL_TIME_TEXT     GColorWhite
  #define COL_DATE_TEXT     GColorChromeYellow
  #define COL_LABEL         GColorChromeYellow

  // Box
  #define COL_BOX           GColorWindsorTan
  #define COL_BOX_DARK      GColorBulgarianRose
  #define COL_TAPE          GColorLightGray
  #define COL_EYE_HOLE      GColorBlack
  #define COL_EYE_GLOW      GColorElectricUltramarine

  // Drum
  #define COL_DRUM          GColorDarkGray
  #define COL_DRUM_HI       GColorLightGray
  #define COL_DRUM_LABEL    GColorChromeYellow

  // Croc
  #define COL_CROC          GColorIslamicGreen
  #define COL_CROC_DARK     GColorDarkGreen
  #define COL_CROC_EYE      GColorYellow
  #define COL_TEETH         GColorWhite

  // Heart (love box)
  #define COL_HEART         GColorRed

  // Legs
  #define COL_LEG           GColorBlack
  #define COL_BOOT          GColorDarkGray

  // Bubbles
  #define COL_Q_BG          GColorWhite
  #define COL_Q_TEXT        GColorBlue
  #define COL_E_BG          GColorYellow
  #define COL_E_TEXT        GColorRed

  // Smoke
  #define COL_SMOKE_LIGHT   GColorWhite
  #define COL_SMOKE_MED     GColorLightGray
  #define COL_SMOKE_DARK    GColorDarkGray
#else
  // B&W fallback for aplite/diorite (won't run on PT2 but keeps app universal)
  #define COL_WALL_BACK     GColorBlack
  #define COL_WALL_PANEL    GColorWhite
  #define COL_WALL_LINE     GColorBlack
  #define COL_FLOOR         GColorBlack
  #define COL_FLOOR_HI      GColorWhite
  #define COL_PIPE          GColorBlack
  #define COL_PIPE_HI       GColorWhite
  #define COL_LAMP          GColorWhite
  #define COL_CAUTION_Y     GColorWhite
  #define COL_CAUTION_K     GColorBlack
  #define COL_VENT          GColorBlack
  #define COL_TIME_TEXT     GColorWhite
  #define COL_DATE_TEXT     GColorWhite
  #define COL_LABEL         GColorWhite
  #define COL_BOX           GColorWhite
  #define COL_BOX_DARK      GColorBlack
  #define COL_TAPE          GColorBlack
  #define COL_EYE_HOLE      GColorBlack
  #define COL_EYE_GLOW      GColorWhite
  #define COL_DRUM          GColorWhite
  #define COL_DRUM_HI       GColorBlack
  #define COL_DRUM_LABEL    GColorBlack
  #define COL_CROC          GColorWhite
  #define COL_CROC_DARK     GColorBlack
  #define COL_CROC_EYE      GColorBlack
  #define COL_TEETH         GColorBlack
  #define COL_HEART         GColorBlack
  #define COL_LEG           GColorWhite
  #define COL_BOOT          GColorBlack
  #define COL_Q_BG          GColorWhite
  #define COL_Q_TEXT        GColorBlack
  #define COL_E_BG          GColorWhite
  #define COL_E_TEXT        GColorBlack
  #define COL_SMOKE_LIGHT   GColorWhite
  #define COL_SMOKE_MED    GColorWhite
  #define COL_SMOKE_DARK    GColorBlack
#endif

// ============================================================================
// LAYOUT (dynamic via layer_get_bounds, but with platform-specific defaults)
// ============================================================================

// On Emery (200x228), sprites scale up. On Basalt/Aplite (144x168), original size.
// We compute everything from bounds at window_load time.

static int s_screen_w = 144;
static int s_screen_h = 168;
static int s_floor_y;
static int s_sprite_w;
static int s_sprite_h;
static int s_feet_h;
static int s_sprite_y;

// ============================================================================
// CONSTANTS
// ============================================================================

#define DISGUISE_BOX        0
#define DISGUISE_DRUM       1
#define DISGUISE_CROC       2
#define DISGUISE_LOVEBOX    3
#define DISGUISE_COUNT      4

// State machine
typedef enum {
  STATE_IDLE,
  STATE_ALERT,
  STATE_GRENADE,
  STATE_VANISHED
} WatchState;

// Animation timing
#define ANIM_TICK_MS              100      // ~10fps
#define ANIM_TICK_MS_LOW_POWER    200
#define LOW_BATTERY_THRESHOLD     20

#define DOUBLE_FLICK_WINDOW_MS    600
#define ALERT_TIMEOUT_MS          5000
#define GRENADE_FRAME_MS          120
#define GRENADE_FRAMES            10
#define RESPAWN_DELAY_MS          5000
#define Q_BLINK_MS                400

// Persist keys
enum {
  PKEY_DISGUISE = 1,
  PKEY_TRAVERSE_MS = 2,
};

// AppMessage keys (defined in package.json messageKeys)
// Clay maps these from camelCase strings to numeric IDs at build time.
// We reference them via MESSAGE_KEY_<name> macros.

// ============================================================================
// GLOBAL STATE
// ============================================================================

static Window     *s_main_window;
static Layer      *s_canvas_layer;       // background hallway + sprite + bubbles
static TextLayer  *s_time_layer;
static TextLayer  *s_date_layer;
static TextLayer  *s_label_layer;        // disguise name

// State flags (lifecycle guards — pattern from tumbling-monkeys)
static bool        s_window_loaded = false;
static bool        s_fully_initialized = false;
static bool        s_in_focus = true;
static bool        s_bt_connected = true;
static bool        s_is_charging = false;
static int         s_battery_level = 100;

// Watchface state
static WatchState  s_state = STATE_IDLE;
static int         s_disguise = DISGUISE_BOX;
static int         s_traverse_ms = 300000;  // default 5 minutes

// Sprite position (fixed-point: actual_x * 100, to allow sub-pixel speeds)
static int32_t     s_sprite_x_fp = 0;

// Animation
static AppTimer   *s_anim_timer = NULL;

// Double-flick detection
static int         s_flick_count = 0;
static AppTimer   *s_flick_window_timer = NULL;

// Alert state
static AppTimer   *s_alert_timeout_timer = NULL;
static AppTimer   *s_q_blink_timer = NULL;
static bool        s_q_visible = true;

// Grenade animation
static AppTimer   *s_grenade_timer = NULL;
static int         s_grenade_frame = 0;
static int         s_grenade_x_at_throw = 0;

// Respawn
static AppTimer   *s_respawn_timer = NULL;

// Animated feet phase (incremented per anim tick during IDLE)
static int         s_feet_phase = 0;

// Buffers
static char        s_time_buf[8];
static char        s_date_buf[16];
static char        s_label_buf[16];

// ============================================================================
// FORWARD DECLARATIONS
// ============================================================================

static void schedule_anim(void);
static void cancel_all_timers(void);
static void enter_idle(void);
static void enter_alert(void);
static void enter_grenade(void);
static void enter_vanished(void);
static void update_label(void);
static void canvas_update_proc(Layer *layer, GContext *ctx);
static uint32_t get_anim_interval(void);
static bool should_animate(void);

// ============================================================================
// HELPERS
// ============================================================================

static int clampi(int v, int lo, int hi) {
  if (v < lo) return lo;
  if (v > hi) return hi;
  return v;
}

static void fillrect(GContext *ctx, int x, int y, int w, int h, GColor c) {
  graphics_context_set_fill_color(ctx, c);
  graphics_fill_rect(ctx, GRect(x, y, w, h), 0, GCornerNone);
}

static void strokerect(GContext *ctx, int x, int y, int w, int h, GColor c) {
  graphics_context_set_stroke_color(ctx, c);
  graphics_draw_rect(ctx, GRect(x, y, w, h));
}

// Scale factor: how much bigger Emery is vs Basalt
static int scale_x(int basalt_x) {
  return (basalt_x * s_screen_w) / 144;
}

static int scale_y(int basalt_y) {
  return (basalt_y * s_screen_h) / 168;
}

// ============================================================================
// BACKGROUND DRAWING — Shadow Moses Hallway
// ============================================================================

static void draw_hallway(GContext *ctx) {
  int W = s_screen_w;
  int FY = s_floor_y;

  int ceiling_h = scale_y(6);
  int wall_top = scale_y(20);

  // Upper dark band (above wall panels)
  fillrect(ctx, 0, 0, W, wall_top, COL_WALL_BACK);

  // Wall panels area
  fillrect(ctx, 0, wall_top, W, FY - wall_top, COL_WALL_PANEL);

  // Ceiling pipe
  fillrect(ctx, 0, 0, W, ceiling_h, COL_PIPE);
  fillrect(ctx, 0, ceiling_h / 3, W, ceiling_h / 3, COL_PIPE_HI);

  // Wall lamps
  int lamp_w = scale_x(10);
  int lamp_h = scale_y(5);
  int lamp_y = ceiling_h + 2;
  fillrect(ctx, scale_x(8), lamp_y, lamp_w, lamp_h, COL_LAMP);
  fillrect(ctx, scale_x(8) + 2, lamp_y + lamp_h, lamp_w - 4, scale_y(4), COL_PIPE);
  fillrect(ctx, W - scale_x(8) - lamp_w, lamp_y, lamp_w, lamp_h, COL_LAMP);
  fillrect(ctx, W - scale_x(8) - lamp_w + 2, lamp_y + lamp_h, lamp_w - 4, scale_y(4), COL_PIPE);

  // Vertical panel separators
  graphics_context_set_stroke_color(ctx, COL_WALL_LINE);
  int panel_step = scale_x(36);
  for (int x = 0; x < W; x += panel_step) {
    graphics_draw_line(ctx, GPoint(x, wall_top), GPoint(x, FY));
  }

  // Horizontal panel lines
  int h1 = wall_top;
  int h2 = wall_top + scale_y(40);
  int h3 = wall_top + scale_y(80);
  graphics_draw_line(ctx, GPoint(0, h1), GPoint(W, h1));
  graphics_draw_line(ctx, GPoint(0, h2), GPoint(W, h2));
  graphics_draw_line(ctx, GPoint(0, h3), GPoint(W, h3));

  // Rivets at panel intersections
  for (int x = 0; x <= W; x += panel_step) {
    fillrect(ctx, x - 1, h1 - 1, 3, 3, COL_WALL_LINE);
    fillrect(ctx, x - 1, h2 - 1, 3, 3, COL_WALL_LINE);
    fillrect(ctx, x - 1, h3 - 1, 3, 3, COL_WALL_LINE);
  }

  // SHADOW MOSES warning sign (rendered as colored rect with stripes — text would be too small)
  int sign_w = scale_x(48);
  int sign_h = scale_y(14);
  int sign_x = (W - sign_w) / 2;
  int sign_y = wall_top + scale_y(4);
  fillrect(ctx, sign_x, sign_y, sign_w, sign_h, COL_CAUTION_Y);
  strokerect(ctx, sign_x, sign_y, sign_w, sign_h, COL_WALL_LINE);
  // dashes mimicking text
  for (int i = 0; i < 7; i++) {
    fillrect(ctx, sign_x + 4 + i * (sign_w - 8) / 7, sign_y + 3, (sign_w - 14) / 7, 2, COL_WALL_LINE);
    fillrect(ctx, sign_x + 4 + i * (sign_w - 8) / 7, sign_y + sign_h - 5, (sign_w - 14) / 7, 2, COL_WALL_LINE);
  }

  // Vent grate (right side)
  int vent_w = scale_x(12);
  int vent_h = scale_y(24);
  int vent_x = W - vent_w - scale_x(4);
  int vent_y = h2 + scale_y(6);
  fillrect(ctx, vent_x, vent_y, vent_w, vent_h, COL_VENT);
  for (int vy = vent_y + 3; vy < vent_y + vent_h - 2; vy += 4) {
    fillrect(ctx, vent_x + 2, vy, vent_w - 4, 2, COL_FLOOR);
  }
  strokerect(ctx, vent_x, vent_y, vent_w, vent_h, COL_WALL_LINE);

  // Caution stripe at floor
  int stripe_h = scale_y(8);
  int stripe_seg = scale_x(8);
  int stripe_y = FY - stripe_h;
  for (int x = 0; x < W; x += stripe_seg * 2) {
    fillrect(ctx, x, stripe_y, stripe_seg, stripe_h, COL_CAUTION_Y);
    fillrect(ctx, x + stripe_seg, stripe_y, stripe_seg, stripe_h, COL_CAUTION_K);
  }

  // Floor
  fillrect(ctx, 0, FY, W, s_screen_h - FY, COL_FLOOR);
  fillrect(ctx, 0, FY, W, 2, COL_FLOOR_HI);
}

// ============================================================================
// SPRITE: FEET
// ============================================================================

static void draw_feet(GContext *ctx, int x, int frame, bool quad) {
  int step = (frame / 3) % 2;
  int leg_w = scale_x(4);
  int boot_h = scale_x(3);

  if (!quad) {
    // Two legs
    int lx = x + scale_x(8);
    int rx = x + scale_x(20);
    int ly = s_floor_y - s_feet_h + (step ? 2 : 0);
    int ry = s_floor_y - s_feet_h + (step ? 0 : 2);

    fillrect(ctx, lx, ly, leg_w, s_feet_h - (step ? 2 : 0), COL_LEG);
    fillrect(ctx, lx - 1, s_floor_y - boot_h, leg_w + 2, boot_h, COL_BOOT);

    fillrect(ctx, rx, ry, leg_w, s_feet_h - (step ? 0 : 2), COL_LEG);
    fillrect(ctx, rx - 1, s_floor_y - boot_h, leg_w + 2, boot_h, COL_BOOT);
  } else {
    // Four legs (love box: two pairs)
    int leg_w_q = scale_x(3);
    int offsets_x[] = { scale_x(4), scale_x(11), scale_x(22), scale_x(29) };
    for (int i = 0; i < 4; i++) {
      int lx = x + offsets_x[i];
      int s_i = (step + (i / 2)) % 2;
      int ly = s_floor_y - s_feet_h + (s_i ? 2 : 0);
      fillrect(ctx, lx, ly, leg_w_q, s_feet_h - (s_i ? 2 : 0), COL_LEG);
      fillrect(ctx, lx - 1, s_floor_y - boot_h, leg_w_q + 2, boot_h, COL_BOOT);
    }
  }
}

// ============================================================================
// SPRITE: DISGUISES
// ============================================================================

static void draw_box(GContext *ctx, int x, int y) {
  int w = s_sprite_w;
  int h = s_sprite_h;

  fillrect(ctx, x, y, w, h, COL_BOX);
  fillrect(ctx, x, y, w, scale_y(6), COL_BOX_DARK);
  fillrect(ctx, x + w / 2 - 1, y, scale_x(3), h, COL_TAPE);
  fillrect(ctx, x, y + h / 2 - 1, w, scale_x(3), COL_TAPE);
  strokerect(ctx, x, y, w, h, COL_WALL_LINE);

  // Eye holes
  int eye_w = scale_x(5), eye_h = scale_y(4);
  fillrect(ctx, x + scale_x(6),  y + scale_y(8), eye_w, eye_h, COL_EYE_HOLE);
  fillrect(ctx, x + scale_x(20), y + scale_y(8), eye_w, eye_h, COL_EYE_HOLE);
  fillrect(ctx, x + scale_x(7),  y + scale_y(9), eye_w - 2, eye_h - 2, COL_EYE_GLOW);
  fillrect(ctx, x + scale_x(21), y + scale_y(9), eye_w - 2, eye_h - 2, COL_EYE_GLOW);
}

static void draw_drum(GContext *ctx, int x, int y) {
  int w = s_sprite_w - scale_x(4);
  int h = s_sprite_h;
  int bx = x + scale_x(2);

  fillrect(ctx, bx, y + scale_y(4), w, h - scale_y(4), COL_DRUM);
  fillrect(ctx, bx, y, w, scale_y(6), COL_DRUM_HI);
  fillrect(ctx, bx + 2, y + 1, w - 4, scale_y(4), COL_DRUM);

  fillrect(ctx, bx, y + scale_y(9),  w, scale_y(2), COL_DRUM_HI);
  fillrect(ctx, bx, y + scale_y(17), w, scale_y(2), COL_DRUM_HI);

  // Yellow label band
  fillrect(ctx, bx + 2, y + scale_y(11), w - 4, scale_y(5), COL_DRUM_LABEL);

  strokerect(ctx, bx, y, w, h, COL_WALL_LINE);
}

static void draw_croc(GContext *ctx, int x, int y) {
  int w = s_sprite_w;
  int h = s_sprite_h;

  fillrect(ctx, x, y + scale_y(4), w, h - scale_y(4), COL_CROC);
  fillrect(ctx, x, y, w - scale_x(4), scale_y(6), COL_CROC);

  // Scale texture
  for (int sx = x + scale_x(2); sx < x + w - scale_x(2); sx += scale_x(5)) {
    fillrect(ctx, sx, y + scale_y(7), scale_x(3), scale_y(2), COL_CROC_DARK);
    fillrect(ctx, sx + 2, y + scale_y(13), scale_x(3), scale_y(2), COL_CROC_DARK);
  }

  // Teeth row
  for (int tx = x + scale_x(2); tx < x + w - scale_x(6); tx += scale_x(5)) {
    fillrect(ctx, tx, y + scale_y(2), scale_x(2), scale_y(3), COL_TEETH);
  }

  // Nostrils
  fillrect(ctx, x + w - scale_x(8), y + scale_y(2), 2, 2, COL_WALL_LINE);
  fillrect(ctx, x + w - scale_x(4), y + scale_y(2), 2, 2, COL_WALL_LINE);

  // Eye
  int eye_x = x + w - scale_x(8);
  int eye_y = y + scale_y(7);
  fillrect(ctx, eye_x, eye_y, scale_x(5), scale_x(5), COL_CROC_EYE);
  fillrect(ctx, eye_x + 1, eye_y + 1, scale_x(3), scale_x(3), COL_WALL_LINE);

  strokerect(ctx, x, y, w, h, COL_WALL_LINE);
}

static void draw_lovebox(GContext *ctx, int x, int y) {
  int w = s_sprite_w + scale_x(8);
  int h = s_sprite_h;
  int bx = x - scale_x(4);

  fillrect(ctx, bx, y, w, h, COL_BOX);
  fillrect(ctx, bx, y, w, scale_y(6), COL_BOX_DARK);

  // Center divider (where two boxes join)
  fillrect(ctx, x + s_sprite_w / 2 - 2, y, scale_x(4), h, COL_TAPE);

  // Horizontal tape
  fillrect(ctx, bx, y + h / 2 - 1, w, scale_x(3), COL_TAPE);

  // Heart in center
  int hx = x + s_sprite_w / 2 - scale_x(4);
  int hy = y + scale_y(9);
  // Two bumps
  fillrect(ctx, hx + 1, hy,     scale_x(3), scale_y(2), COL_HEART);
  fillrect(ctx, hx + 5, hy,     scale_x(3), scale_y(2), COL_HEART);
  // Body
  fillrect(ctx, hx,     hy + 2, scale_x(8), scale_y(3), COL_HEART);
  fillrect(ctx, hx + 1, hy + 5, scale_x(6), scale_y(2), COL_HEART);
  fillrect(ctx, hx + 2, hy + 7, scale_x(4), scale_y(1), COL_HEART);
  fillrect(ctx, hx + 3, hy + 8, scale_x(2), scale_y(1), COL_HEART);

  // Four eye holes (one pair per box)
  int eye_w = scale_x(4), eye_h = scale_y(3);
  fillrect(ctx, bx + scale_x(4),                   y + scale_y(8), eye_w, eye_h, COL_EYE_HOLE);
  fillrect(ctx, bx + scale_x(10),                  y + scale_y(8), eye_w, eye_h, COL_EYE_HOLE);
  fillrect(ctx, x + s_sprite_w / 2 + scale_x(2),   y + scale_y(8), eye_w, eye_h, COL_EYE_HOLE);
  fillrect(ctx, x + s_sprite_w / 2 + scale_x(8),   y + scale_y(8), eye_w, eye_h, COL_EYE_HOLE);

  strokerect(ctx, bx, y, w, h, COL_WALL_LINE);
}

// ============================================================================
// SPRITE: ALERT BUBBLES
// ============================================================================

static void draw_q_bubble(GContext *ctx, int x) {
  int bw = scale_x(18);
  int bh = scale_y(18);
  int bx = x + s_sprite_w / 2 - bw / 2;
  int by = s_sprite_y - bh - scale_y(4);

  fillrect(ctx, bx, by, bw, bh, COL_Q_BG);
  strokerect(ctx, bx, by, bw, bh, COL_WALL_LINE);

  // Tail
  fillrect(ctx, bx + bw / 2 - 2, by + bh, scale_x(4), scale_y(4), COL_Q_BG);
  graphics_context_set_stroke_color(ctx, COL_WALL_LINE);
  graphics_draw_line(ctx, GPoint(bx + bw / 2 - 2, by + bh),
                          GPoint(bx + bw / 2,     by + bh + scale_y(4)));
  graphics_draw_line(ctx, GPoint(bx + bw / 2 + 2, by + bh),
                          GPoint(bx + bw / 2,     by + bh + scale_y(4)));

  // ? mark (pixel-art) — beefier so it reads on small screen
  int qx = bx + bw / 2 - scale_x(4);
  int qy = by + scale_y(3);
  // Top curve
  fillrect(ctx, qx + scale_x(1), qy,                  scale_x(6), scale_y(2), COL_Q_TEXT);
  fillrect(ctx, qx,              qy + scale_y(1),     scale_x(2), scale_y(2), COL_Q_TEXT);
  fillrect(ctx, qx + scale_x(6), qy + scale_y(1),     scale_x(2), scale_y(3), COL_Q_TEXT);
  // Hook into stem
  fillrect(ctx, qx + scale_x(4), qy + scale_y(3),     scale_x(3), scale_y(2), COL_Q_TEXT);
  // Stem
  fillrect(ctx, qx + scale_x(3), qy + scale_y(5),     scale_x(2), scale_y(3), COL_Q_TEXT);
  // Dot
  fillrect(ctx, qx + scale_x(3), qy + scale_y(9),     scale_x(2), scale_y(2), COL_Q_TEXT);
}

static void draw_e_bubble(GContext *ctx, int x) {
  int bw = scale_x(18);
  int bh = scale_y(18);
  int bx = x + s_sprite_w / 2 - bw / 2;
  int by = s_sprite_y - bh - scale_y(4);

  fillrect(ctx, bx, by, bw, bh, COL_E_BG);
  strokerect(ctx, bx, by, bw, bh, COL_WALL_LINE);

  fillrect(ctx, bx + bw / 2 - 2, by + bh, scale_x(4), scale_y(4), COL_E_BG);
  graphics_context_set_stroke_color(ctx, COL_WALL_LINE);
  graphics_draw_line(ctx, GPoint(bx + bw / 2 - 2, by + bh),
                          GPoint(bx + bw / 2,     by + bh + scale_y(4)));
  graphics_draw_line(ctx, GPoint(bx + bw / 2 + 2, by + bh),
                          GPoint(bx + bw / 2,     by + bh + scale_y(4)));

  // ! mark
  int ex = bx + bw / 2 - 1;
  int ey = by + scale_y(3);
  fillrect(ctx, ex - 1, ey,             scale_x(4), scale_y(8), COL_E_TEXT);
  fillrect(ctx, ex - 1, ey + scale_y(10), scale_x(4), scale_y(2), COL_E_TEXT);
}

// ============================================================================
// GRENADE ANIMATION
// ============================================================================

static void draw_grenade_anim(GContext *ctx, int x, int frame) {
  // Frames 0-3: grenade arcs out and to the right
  // Frames 4-9: smoke puff expands
  if (frame < 4) {
    int gx = x + s_sprite_w / 2 + frame * scale_x(7);
    int gy = s_sprite_y + scale_y(8) - frame * scale_y(3);
    fillrect(ctx, gx, gy, scale_x(5), scale_x(5), COL_SMOKE_DARK);
    fillrect(ctx, gx + 1, gy - 2, scale_x(3), scale_x(2), COL_SMOKE_MED);
  } else {
    int r = (frame - 3) * scale_x(5);
    int cx = x + s_sprite_w / 2 + scale_x(20);
    int cy = s_sprite_y + scale_y(8);
    graphics_context_set_fill_color(ctx, COL_SMOKE_MED);
    graphics_fill_circle(ctx, GPoint(cx, cy), r);
    graphics_context_set_fill_color(ctx, COL_SMOKE_LIGHT);
    graphics_fill_circle(ctx, GPoint(cx - 3, cy - 3), r / 2);
    graphics_context_set_fill_color(ctx, COL_SMOKE_DARK);
    graphics_fill_circle(ctx, GPoint(cx + 3, cy + 2), r / 3);
  }
}

// ============================================================================
// MAIN CANVAS UPDATE
// ============================================================================

static void canvas_update_proc(Layer *layer, GContext *ctx) {
  if (!s_window_loaded) return;

  draw_hallway(ctx);

  if (s_state == STATE_VANISHED) {
    return;  // sprite hidden
  }

  int x = (int)(s_sprite_x_fp / 100);

  if (s_state == STATE_GRENADE) {
    draw_grenade_anim(ctx, x, s_grenade_frame);
    return;
  }

  bool is_lovebox = (s_disguise == DISGUISE_LOVEBOX);
  bool moving = (s_state == STATE_IDLE);

  // Feet
  draw_feet(ctx, is_lovebox ? x - scale_x(4) : x,
            moving ? s_feet_phase : 0, is_lovebox);

  // Body
  switch (s_disguise) {
    case DISGUISE_BOX:     draw_box(ctx, x, s_sprite_y);     break;
    case DISGUISE_DRUM:    draw_drum(ctx, x, s_sprite_y);    break;
    case DISGUISE_CROC:    draw_croc(ctx, x, s_sprite_y);    break;
    case DISGUISE_LOVEBOX: draw_lovebox(ctx, x, s_sprite_y); break;
  }

  // Bubble overlays
  if (s_state == STATE_ALERT && s_q_visible) {
    draw_q_bubble(ctx, x);
  }
}

// ============================================================================
// LIFECYCLE GUARDS
// ============================================================================

static bool should_animate(void) {
  return s_fully_initialized
      && s_window_loaded
      && s_in_focus
      && s_bt_connected
      && !s_is_charging;
}

static uint32_t get_anim_interval(void) {
  uint32_t interval = ANIM_TICK_MS;
#ifndef PBL_COLOR
  interval = ANIM_TICK_MS_LOW_POWER;
#endif
  if (s_battery_level <= LOW_BATTERY_THRESHOLD) {
    interval = ANIM_TICK_MS_LOW_POWER;
  }
  if (interval < 50) interval = 50;
  return interval;
}

// ============================================================================
// IDLE ANIMATION TICK
// ============================================================================

static void anim_tick(void *data);

static void schedule_anim(void) {
  if (s_anim_timer) return;  // already scheduled
  if (!should_animate()) return;
  if (s_state != STATE_IDLE) return;
  s_anim_timer = app_timer_register(get_anim_interval(), anim_tick, NULL);
}

static void anim_tick(void *data) {
  s_anim_timer = NULL;
  if (s_state != STATE_IDLE) return;
  if (!should_animate()) return;

  // Compute how far to move per tick
  // Total path = (screen_w + 2 * sprite_w) so sprite fully exits before reset
  int path_px = s_screen_w + 2 * s_sprite_w;
  int total_ticks = s_traverse_ms / get_anim_interval();
  if (total_ticks < 1) total_ticks = 1;

  // Fixed-point: path * 100 / ticks = dx_fp
  int32_t dx_fp = ((int32_t)path_px * 100) / total_ticks;
  if (dx_fp < 1) dx_fp = 1;

  s_sprite_x_fp += dx_fp;

  // Wrap around when fully off-screen right
  if (s_sprite_x_fp > (int32_t)(s_screen_w + s_sprite_w) * 100) {
    s_sprite_x_fp = -(int32_t)s_sprite_w * 100;
  }

  s_feet_phase++;

  if (s_canvas_layer) layer_mark_dirty(s_canvas_layer);
  schedule_anim();
}

// ============================================================================
// STATE TRANSITIONS
// ============================================================================

static void cancel_alert_timers(void) {
  if (s_alert_timeout_timer) {
    app_timer_cancel(s_alert_timeout_timer);
    s_alert_timeout_timer = NULL;
  }
  if (s_q_blink_timer) {
    app_timer_cancel(s_q_blink_timer);
    s_q_blink_timer = NULL;
  }
}

static void cancel_all_timers(void) {
  if (s_anim_timer)            { app_timer_cancel(s_anim_timer);            s_anim_timer = NULL; }
  if (s_flick_window_timer)    { app_timer_cancel(s_flick_window_timer);    s_flick_window_timer = NULL; }
  if (s_alert_timeout_timer)   { app_timer_cancel(s_alert_timeout_timer);   s_alert_timeout_timer = NULL; }
  if (s_q_blink_timer)         { app_timer_cancel(s_q_blink_timer);         s_q_blink_timer = NULL; }
  if (s_grenade_timer)         { app_timer_cancel(s_grenade_timer);         s_grenade_timer = NULL; }
  if (s_respawn_timer)         { app_timer_cancel(s_respawn_timer);         s_respawn_timer = NULL; }
}

static void enter_idle(void) {
  cancel_alert_timers();
  s_state = STATE_IDLE;
  if (s_canvas_layer) layer_mark_dirty(s_canvas_layer);
  schedule_anim();
}

static void q_blink_tick(void *data) {
  s_q_blink_timer = NULL;
  if (s_state != STATE_ALERT) return;
  s_q_visible = !s_q_visible;
  if (s_canvas_layer) layer_mark_dirty(s_canvas_layer);
  s_q_blink_timer = app_timer_register(Q_BLINK_MS, q_blink_tick, NULL);
}

static void alert_timeout(void *data) {
  s_alert_timeout_timer = NULL;
  if (s_state == STATE_ALERT) {
    enter_idle();
  }
}

static void enter_alert(void) {
  if (s_anim_timer) { app_timer_cancel(s_anim_timer); s_anim_timer = NULL; }
  s_state = STATE_ALERT;
  s_q_visible = true;
  s_q_blink_timer = app_timer_register(Q_BLINK_MS, q_blink_tick, NULL);
  s_alert_timeout_timer = app_timer_register(ALERT_TIMEOUT_MS, alert_timeout, NULL);
  if (s_canvas_layer) layer_mark_dirty(s_canvas_layer);
}

static void respawn_tick(void *data) {
  s_respawn_timer = NULL;
  s_sprite_x_fp = -(int32_t)s_sprite_w * 100;
  enter_idle();
}

static void enter_vanished(void) {
  s_state = STATE_VANISHED;
  if (s_canvas_layer) layer_mark_dirty(s_canvas_layer);
  s_respawn_timer = app_timer_register(RESPAWN_DELAY_MS, respawn_tick, NULL);
}

static void grenade_frame_tick(void *data) {
  s_grenade_timer = NULL;
  s_grenade_frame++;
  if (s_canvas_layer) layer_mark_dirty(s_canvas_layer);

  if (s_grenade_frame >= GRENADE_FRAMES) {
    enter_vanished();
  } else {
    s_grenade_timer = app_timer_register(GRENADE_FRAME_MS, grenade_frame_tick, NULL);
  }
}

static void enter_grenade(void) {
  cancel_alert_timers();
  s_state = STATE_GRENADE;
  s_grenade_frame = 0;
  s_grenade_x_at_throw = (int)(s_sprite_x_fp / 100);
  vibes_double_pulse();
  s_grenade_timer = app_timer_register(GRENADE_FRAME_MS, grenade_frame_tick, NULL);
  if (s_canvas_layer) layer_mark_dirty(s_canvas_layer);
}

// ============================================================================
// DOUBLE-FLICK DETECTION
// ============================================================================

static void flick_window_expired(void *data) {
  s_flick_window_timer = NULL;
  s_flick_count = 0;
}

static void accel_tap_handler(AccelAxisType axis, int32_t direction) {
  if (!s_fully_initialized) return;

  s_flick_count++;

  if (s_flick_count == 1) {
    if (s_flick_window_timer) app_timer_cancel(s_flick_window_timer);
    s_flick_window_timer = app_timer_register(DOUBLE_FLICK_WINDOW_MS, flick_window_expired, NULL);
    return;
  }

  // Second (or later) tap within window — count as double-flick
  if (s_flick_window_timer) {
    app_timer_cancel(s_flick_window_timer);
    s_flick_window_timer = NULL;
  }
  s_flick_count = 0;

  // Trigger state transition based on current state
  if (s_state == STATE_IDLE) {
    enter_alert();
  } else if (s_state == STATE_ALERT) {
    enter_grenade();
  }
  // GRENADE / VANISHED states ignore flicks
}

// ============================================================================
// BUTTONS — disguise cycling
// ============================================================================

static void update_label(void) {
  static const char *names[] = { "BOX", "DRUM", "CROC", "LOVE BOX" };
  snprintf(s_label_buf, sizeof(s_label_buf), "%s", names[s_disguise]);
  if (s_label_layer) text_layer_set_text(s_label_layer, s_label_buf);
}

static void up_click_handler(ClickRecognizerRef recognizer, void *context) {
  if (!s_fully_initialized) return;
  s_disguise = (s_disguise + DISGUISE_COUNT - 1) % DISGUISE_COUNT;
  persist_write_int(PKEY_DISGUISE, s_disguise);
  update_label();
  if (s_canvas_layer) layer_mark_dirty(s_canvas_layer);
}

static void down_click_handler(ClickRecognizerRef recognizer, void *context) {
  if (!s_fully_initialized) return;
  s_disguise = (s_disguise + 1) % DISGUISE_COUNT;
  persist_write_int(PKEY_DISGUISE, s_disguise);
  update_label();
  if (s_canvas_layer) layer_mark_dirty(s_canvas_layer);
}

static void click_config_provider(void *context) {
  window_single_click_subscribe(BUTTON_ID_UP, up_click_handler);
  window_single_click_subscribe(BUTTON_ID_DOWN, down_click_handler);
}

// ============================================================================
// TIME UPDATE
// ============================================================================

static void update_time(void) {
  if (!s_fully_initialized || !s_time_layer || !s_date_layer) return;

  time_t temp = time(NULL);
  struct tm *tick_time = localtime(&temp);

  strftime(s_time_buf, sizeof(s_time_buf),
           clock_is_24h_style() ? "%H:%M" : "%I:%M", tick_time);
  text_layer_set_text(s_time_layer, s_time_buf);

  strftime(s_date_buf, sizeof(s_date_buf), "%a %b %d", tick_time);
  text_layer_set_text(s_date_layer, s_date_buf);
}

static void tick_handler(struct tm *tick_time, TimeUnits units_changed) {
  update_time();
}

// ============================================================================
// SYSTEM SERVICES
// ============================================================================

static void battery_callback(BatteryChargeState state) {
  s_battery_level = state.charge_percent;
  s_is_charging = state.is_plugged;
  if (s_fully_initialized) schedule_anim();
}

static void bt_handler(bool connected) {
  s_bt_connected = connected;
  if (s_fully_initialized) schedule_anim();
}

static void focus_handler(bool in_focus) {
  s_in_focus = in_focus;
  if (!in_focus) {
    if (s_anim_timer) { app_timer_cancel(s_anim_timer); s_anim_timer = NULL; }
  } else {
    schedule_anim();
  }
}

// ============================================================================
// APP MESSAGE — receive Clay settings from phone
// ============================================================================

static void inbox_received_handler(DictionaryIterator *iter, void *context) {
  Tuple *t;

  t = dict_find(iter, MESSAGE_KEY_disguise);
  if (t) {
    s_disguise = clampi((int)t->value->int32, 0, DISGUISE_COUNT - 1);
    persist_write_int(PKEY_DISGUISE, s_disguise);
    update_label();
  }

  t = dict_find(iter, MESSAGE_KEY_traverseMs);
  if (t) {
    int v = (int)t->value->int32;
    if (v < 60000) v = 60000;
    if (v > 600000) v = 600000;
    s_traverse_ms = v;
    persist_write_int(PKEY_TRAVERSE_MS, s_traverse_ms);
  }

  if (s_canvas_layer) layer_mark_dirty(s_canvas_layer);
}

// ============================================================================
// WINDOW LIFECYCLE
// ============================================================================

static void main_window_load(Window *window) {
  Layer *root = window_get_root_layer(window);
  GRect bounds = layer_get_bounds(root);

  s_screen_w = bounds.size.w;
  s_screen_h = bounds.size.h;

  // Compute scaled layout
  s_floor_y    = (s_screen_h * 140) / 168;
  s_sprite_w   = scale_x(32);
  s_sprite_h   = scale_y(24);
  s_feet_h     = scale_y(8);
  s_sprite_y   = s_floor_y - s_sprite_h - s_feet_h;

  // Initialize sprite position off-screen left
  s_sprite_x_fp = -(int32_t)s_sprite_w * 100;

  s_window_loaded = true;

  // Canvas layer (background + sprite + bubbles)
  s_canvas_layer = layer_create(bounds);
  layer_set_update_proc(s_canvas_layer, canvas_update_proc);
  layer_add_child(root, s_canvas_layer);

  // Time text — large, centered upper area
  int time_y = scale_y(28);
  int time_h = scale_y(48);
  s_time_layer = text_layer_create(GRect(0, time_y, s_screen_w, time_h));
  text_layer_set_background_color(s_time_layer, GColorClear);
  text_layer_set_text_color(s_time_layer, COL_TIME_TEXT);
  text_layer_set_font(s_time_layer, fonts_get_system_font(FONT_KEY_LECO_42_NUMBERS));
  text_layer_set_text_alignment(s_time_layer, GTextAlignmentCenter);
  layer_add_child(root, text_layer_get_layer(s_time_layer));

  // Date below time (with a small gap)
  int date_y = time_y + time_h - scale_y(6);
  s_date_layer = text_layer_create(GRect(0, date_y, s_screen_w, scale_y(20)));
  text_layer_set_background_color(s_date_layer, GColorClear);
  text_layer_set_text_color(s_date_layer, COL_DATE_TEXT);
  text_layer_set_font(s_date_layer, fonts_get_system_font(FONT_KEY_GOTHIC_18_BOLD));
  text_layer_set_text_alignment(s_date_layer, GTextAlignmentCenter);
  layer_add_child(root, text_layer_get_layer(s_date_layer));

  // Disguise label — bottom-left of floor
  s_label_layer = text_layer_create(GRect(scale_x(4), s_floor_y + scale_y(2), s_screen_w / 2, scale_y(20)));
  text_layer_set_background_color(s_label_layer, GColorClear);
  text_layer_set_text_color(s_label_layer, COL_LABEL);
  text_layer_set_font(s_label_layer, fonts_get_system_font(FONT_KEY_GOTHIC_14_BOLD));
  text_layer_set_text_alignment(s_label_layer, GTextAlignmentLeft);
  layer_add_child(root, text_layer_get_layer(s_label_layer));

  // Click config (disguise cycling)
  window_set_click_config_provider(window, click_config_provider);

  // Battery state initial peek
  battery_callback(battery_state_service_peek());
  s_bt_connected = connection_service_peek_pebble_app_connection();

  s_fully_initialized = true;

  update_label();
  update_time();
  schedule_anim();
}

static void main_window_unload(Window *window) {
  s_fully_initialized = false;
  s_window_loaded = false;

  cancel_all_timers();

  if (s_time_layer)   { text_layer_destroy(s_time_layer);   s_time_layer = NULL; }
  if (s_date_layer)   { text_layer_destroy(s_date_layer);   s_date_layer = NULL; }
  if (s_label_layer)  { text_layer_destroy(s_label_layer);  s_label_layer = NULL; }
  if (s_canvas_layer) { layer_destroy(s_canvas_layer);      s_canvas_layer = NULL; }
}

// ============================================================================
// APP INIT / DEINIT
// ============================================================================

static void init(void) {
  // Load persisted settings
  if (persist_exists(PKEY_DISGUISE))    s_disguise    = persist_read_int(PKEY_DISGUISE);
  if (persist_exists(PKEY_TRAVERSE_MS)) s_traverse_ms = persist_read_int(PKEY_TRAVERSE_MS);
  if (s_traverse_ms < 60000 || s_traverse_ms > 600000) s_traverse_ms = 300000;
  s_disguise = clampi(s_disguise, 0, DISGUISE_COUNT - 1);

  s_main_window = window_create();
  window_set_window_handlers(s_main_window, (WindowHandlers){
    .load = main_window_load,
    .unload = main_window_unload,
  });
  window_stack_push(s_main_window, true);

  // Subscribe to system services
  tick_timer_service_subscribe(MINUTE_UNIT, tick_handler);
  battery_state_service_subscribe(battery_callback);
  connection_service_subscribe((ConnectionHandlers){
    .pebble_app_connection_handler = bt_handler,
    .pebblekit_connection_handler = NULL,
  });
  app_focus_service_subscribe(focus_handler);

  // Tap (wrist flick) detection — canonical battery-friendly approach
  accel_tap_service_subscribe(accel_tap_handler);

  // AppMessage from phone
  app_message_register_inbox_received(inbox_received_handler);
  app_message_open(128, 128);
}

static void deinit(void) {
  cancel_all_timers();

  tick_timer_service_unsubscribe();
  battery_state_service_unsubscribe();
  connection_service_unsubscribe();
  app_focus_service_unsubscribe();
  accel_tap_service_unsubscribe();

  if (s_main_window) {
    window_destroy(s_main_window);
    s_main_window = NULL;
  }
}

int main(void) {
  init();
  app_event_loop();
  deinit();
  return 0;
}
