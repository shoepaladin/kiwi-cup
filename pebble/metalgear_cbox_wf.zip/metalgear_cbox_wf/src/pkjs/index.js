// PebbleKit JS entry point.
// Uses Clay to render a settings page on the phone Pebble/Rebble app.

var Clay = require('@rebble/clay');
var clayConfig = require('./config');
var clay = new Clay(clayConfig);

Pebble.addEventListener('ready', function() {
  console.log('Metal Gear Watch JS ready');
});

// Clay handles the showConfiguration / webviewclosed events automatically.
// AppMessages flow into the C inbox handler via the messageKeys defined in package.json.
