module.exports = [
  {
    "type": "heading",
    "defaultValue": "METAL GEAR WATCH"
  },
  {
    "type": "text",
    "defaultValue": "Configure Snake's disguise and shuffle speed."
  },
  {
    "type": "section",
    "items": [
      {
        "type": "heading",
        "defaultValue": "Default Disguise"
      },
      {
        "type": "select",
        "messageKey": "disguise",
        "defaultValue": "0",
        "label": "Disguise",
        "options": [
          { "label": "Cardboard Box",      "value": "0" },
          { "label": "Oil Drum",           "value": "1" },
          { "label": "Crocodile Head",     "value": "2" },
          { "label": "Double Love Box",    "value": "3" }
        ]
      },
      {
        "type": "text",
        "defaultValue": "You can also cycle disguises on the watch using the Up/Down buttons."
      }
    ]
  },
  {
    "type": "section",
    "items": [
      {
        "type": "heading",
        "defaultValue": "Shuffle Speed"
      },
      {
        "type": "radiogroup",
        "messageKey": "traverseMs",
        "label": "Time to cross screen",
        "defaultValue": "300000",
        "options": [
          { "label": "1 minute",   "value": "60000" },
          { "label": "5 minutes",  "value": "300000" },
          { "label": "10 minutes", "value": "600000" }
        ]
      }
    ]
  },
  {
    "type": "section",
    "items": [
      {
        "type": "heading",
        "defaultValue": "Controls"
      },
      {
        "type": "text",
        "defaultValue": "Double-flick wrist to trigger ALERT (?). Double-flick again during alert to throw a smoke grenade and vanish. Time format follows your watch's system 12/24-hour setting."
      }
    ]
  },
  {
    "type": "submit",
    "defaultValue": "Save Settings"
  }
];
